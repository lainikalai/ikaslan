pageextension 99271 "IKA Mail Purchase Invoice" extends "Purchase Invoice"
{
    // FactBoxes "Emails recibidos" y "Emails enviados": emails con el proveedor (y el contacto del documento)
    // cuyo asunto contiene el nº de la factura o los nº de factura/pedido del proveedor.
    layout
    {
        addfirst(factboxes)
        {
            part("IKA Mail Received Emails"; "IKA Mail Address Emails")
            {
                ApplicationArea = All;
                Caption = 'Emails recibidos';
            }
            part("IKA Mail Sent Emails"; "IKA Mail Address Emails")
            {
                ApplicationArea = All;
                Caption = 'Emails enviados';
            }
        }
    }

    trigger OnAfterGetCurrRecord()
    var
        AddressSearch: Codeunit "IKA Mail Address Search";
        Addresses: Text;
        SubjectFilter: Text;
    begin
        Addresses := AddressSearch.GetVendorAddresses(Rec."Buy-from Vendor No.", Rec."Buy-from Contact No.");
        SubjectFilter := AddressSearch.GetDocumentSubjectFilter(Rec."No.", Rec."Vendor Invoice No.", Rec."Vendor Order No.");
        CurrPage."IKA Mail Received Emails".Page.SetContext(Addresses, SubjectFilter, Enum::"IKA Mail Address Direction"::Received);
        CurrPage."IKA Mail Sent Emails".Page.SetContext(Addresses, SubjectFilter, Enum::"IKA Mail Address Direction"::Sent);
    end;
}
